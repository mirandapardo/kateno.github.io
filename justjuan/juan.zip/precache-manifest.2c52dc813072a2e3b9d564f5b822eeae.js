self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2921ff442c72c093deb68a8c5fb7420d",
    "url": "/index.html"
  },
  {
    "revision": "7d29d9f96545339cc013",
    "url": "/static/css/main.d26d5325.chunk.css"
  },
  {
    "revision": "387baba46b0cf31306c3",
    "url": "/static/js/2.0d08ee96.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.0d08ee96.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7d29d9f96545339cc013",
    "url": "/static/js/main.701a8d07.chunk.js"
  },
  {
    "revision": "89ea531a83bfbfa2ab21",
    "url": "/static/js/runtime-main.a6fc8b1a.js"
  }
]);